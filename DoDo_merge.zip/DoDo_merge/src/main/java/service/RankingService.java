package service;

import java.util.List;

import vo.RankingVO;

public interface RankingService {

	List<RankingVO> selectList(); //selectList
	
}