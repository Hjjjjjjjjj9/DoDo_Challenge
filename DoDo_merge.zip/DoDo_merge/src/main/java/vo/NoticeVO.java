package vo;

import lombok.Data;

@Data
public class NoticeVO {
	private int seq;
	private String title;
	private String regdate;
	private String content;
	private String id;
	private int cnt;
}

// 